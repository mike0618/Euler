# Maximum path sum I
import time
def e18():
	start = time.time()
	f=open("num_triangle.txt")
	summ=[75]
	cnt=0
	i=0
	for s in f:
		lst=s.split()
		for n in lst:
			
	# lst=list(range(1,x+2))
	# while lst[1]!=y+1:
		# i=0
		# for n in lst[1:]:
			# i+=1
			# lst[i]=n+lst[i-1]
	# print(f"There are {lst[-1]} routes in {x}x{y} grid!")
	end = time.time() - start
	print("Runtime =", end)
print(e18())	# 21124 
