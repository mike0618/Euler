# Sum of digits in 2**1000
def e16():
	summ=0
	for n in str(2**1000):
		summ+=int(n)
	print(summ)
e16()

